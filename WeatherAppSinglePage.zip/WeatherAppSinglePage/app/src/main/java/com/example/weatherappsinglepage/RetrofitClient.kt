package com.example.weatherappsinglepage

import retrofit2.Retrofit
import retrofit2.converter.gson.GsonConverterFactory

// from geeksforgeeks.org/retrofit-with-kotlin-coroutine-in-android/
object RetrofitClient {
    fun getInstance(): Retrofit {
        return Retrofit.Builder().baseUrl("https://api.openweathermap.org").addConverterFactory(
            GsonConverterFactory.create()
        ).build()
    }
}