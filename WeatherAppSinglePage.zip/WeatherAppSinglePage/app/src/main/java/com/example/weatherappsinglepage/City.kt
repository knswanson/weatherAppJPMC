package com.example.weatherappsinglepage

//import kotlinx.serialization.*

//@Serializable
data class City(
    val name: String,
    val weather: List<Weather>
)