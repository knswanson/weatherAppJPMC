package com.example.weatherappsinglepage

import retrofit2.Response
import retrofit2.http.GET
import retrofit2.http.Query

interface ApiInterface {
    @GET("/data/2.5/weather")
    suspend fun getAllUsers(@Query("q") cityName: String, @Query("APPID") apiKey: String): Response<City>
}