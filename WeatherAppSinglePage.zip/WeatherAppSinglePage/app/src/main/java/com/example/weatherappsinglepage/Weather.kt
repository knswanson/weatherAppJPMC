package com.example.weatherappsinglepage

//import kotlinx.serialization.*

//@Serializable
data class Weather(
    val id: Number,
    val main: String,
    val description: String,
    val icon: String // stretch goal, implement icons
)