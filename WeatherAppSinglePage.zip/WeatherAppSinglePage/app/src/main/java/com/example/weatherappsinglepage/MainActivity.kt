package com.example.weatherappsinglepage

import android.Manifest
import android.annotation.SuppressLint
import android.content.Context
import android.content.pm.PackageManager
import android.location.Location
import android.location.LocationManager
import android.os.Bundle
import android.util.Log
import android.widget.ArrayAdapter
import android.widget.ListView
import android.widget.SearchView
import android.widget.TextView
import androidx.activity.ComponentActivity
import androidx.core.app.ActivityCompat
//import com.google.android.gms.location.FusedLocationProviderClient
//import com.google.android.gms.location.LocationServices
import kotlinx.coroutines.CoroutineExceptionHandler
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.DelicateCoroutinesApi
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.Job
import kotlinx.coroutines.delay
import kotlinx.coroutines.launch
import kotlinx.serialization.ExperimentalSerializationApi


class MainActivity : ComponentActivity() {
    lateinit var searchView: SearchView
//    lateinit var listView: ListView
//    lateinit var adapter: ArrayAdapter<String>
    lateinit var txtData: TextView
//    private lateinit var fusedLocationClient: FusedLocationProviderClient

    @OptIn(DelicateCoroutinesApi::class, ExperimentalSerializationApi::class)
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)
        //setupLocationServices() ***see bottom of file for explanation

        // todo : move to separate setup functions for cleaner easier to read code
        val sharedPreference = getSharedPreferences("PREFERENCE_NAME", Context.MODE_PRIVATE)
        val mString = sharedPreference.getString("city", "City results")

        searchView = findViewById(R.id.search_view)
        txtData = findViewById(R.id.txtData)
        txtData.text = mString

        val weatherApi = RetrofitClient.getInstance().create(ApiInterface::class.java)

        val coroutineExceptionHandler = CoroutineExceptionHandler{_, throwable ->
            throwable.printStackTrace()
        }

        var queryTextChangedJob: Job? = null // this and below from https://stackoverflow.com/questions/34955109/throttle-onquerytextchange-in-searchview

        fun SearchView.setupQueryTextSubmit(callback: (String?) -> Unit) {
            setOnQueryTextListener(object : SearchView.OnQueryTextListener {
                override fun onQueryTextSubmit(query: String): Boolean {
                    queryTextChangedJob?.cancel()

                    queryTextChangedJob = CoroutineScope(Dispatchers.IO + coroutineExceptionHandler).launch {
                        delay(500)
                        val response = weatherApi.getAllUsers(query, "746a69e2e703ebdb3065d42dbe45a464") // remove hardcode, secure key from users
                        val responseBody = response.body().toString()
                        txtData.text = responseBody // better way of storing results below

                        sharedPreference.edit().putString("city", responseBody).apply()
                    }
                    return true
                }

                override fun onQueryTextChange(query: String?): Boolean {
                    return false
                }
            })
        }

        searchView.setupQueryTextSubmit {}

        // TODO : create list of results in a pretty manner (just setting text for now, prioritizing location services ask)
//        var items = ArrayList<String>()
//        val city = Json.decodeFromString<City>(currentQuery)
//
//        items.add("City: " + city.name)
//        adapter = ArrayAdapter<String>(this, android.R.layout.simple_list_item_1, items)
//        listView.adapter = adapter



        // **trying out runOnUi thread below**

//        searchView.setOnSearchClickListener {
//
//            CoroutineScope(Dispatchers.IO + coroutineExceptionHandler).launch {
//                var query: String = ""
//                //runOnUiThread {
//                    // Stuff that updates the UI
//                    query =  searchView.query.toString()
//                    txtData.text = query
//                //}
//                val response =
//                    weatherApi.getAllUsers(query, "746a69e2e703ebdb3065d42dbe45a464") //hardcode
//                if (response.body() != null) {
//                    runOnUiThread {
//                        //txtData.text = response.body().toString()
//                    }
//                }
//            }
//        }
    }

    private fun setupLocationServices() {
//        fusedLocationClient = LocationServices.getFusedLocationProviderClient(this)

        @SuppressLint("MissingPermission")
        fun obtainLocalization(){
            if (ActivityCompat.checkSelfPermission(
                    this,
                    Manifest.permission.ACCESS_FINE_LOCATION
                ) != PackageManager.PERMISSION_GRANTED && ActivityCompat.checkSelfPermission(
                    this,
                    Manifest.permission.ACCESS_COARSE_LOCATION
                ) != PackageManager.PERMISSION_GRANTED
            ) {
                // TODO: Consider calling
                //    ActivityCompat#requestPermissions
                // here to request the missing permissions, and then overriding
                //   public void onRequestPermissionsResult(int requestCode, String[] permissions,
                //                                          int[] grantResults)
                // to handle the case where the user grants the permission. See the documentation
                // for ActivityCompat#requestPermissions for more details.
                return
            }
//            fusedLocationClient.lastLocation
//                .addOnSuccessListener { location: Location? ->
//                    var latitude = location?.latitude
//                    var longitude = location?.longitude
//                    // todo: get city from lat+long, set result to it
//                }
        }

        obtainLocalization() // this is one option, downside is location will be null when switching location off and on again on some devices
        // from: https://stackoverflow.com/questions/45958226/get-location-android-kotlin
        // another option is to implement android location permissions https://developer.android.com/develop/sensors-and-location/location/permissions
    }
}